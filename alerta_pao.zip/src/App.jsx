
import { useEffect } from "react";

const steps = [
  { time: "10:00", label: "Ativação do Levain", message: "Misture levain mãe, farinha e água. Deixe crescer até dobrar." },
  { time: "15:00", label: "Início da Autólise", message: "Misture farinha branca, integral e água. Descanse por 1h." },
  { time: "16:00", label: "Adicionar Levain", message: "Misture o levain na massa da autólise." },
  { time: "16:20", label: "Adicionar Sal", message: "Adicione 10g de sal e misture bem." },
  { time: "17:00", label: "Dobra 1", message: "Realize a primeira dobra na massa." },
  { time: "17:40", label: "Dobra 2", message: "Realize a segunda dobra na massa." },
  { time: "18:20", label: "Dobra 3", message: "Realize a terceira dobra na massa." },
  { time: "20:30", label: "Pré-modelagem", message: "Vire e boleie a massa. Deixe descansar por 20 min." },
  { time: "20:50", label: "Modelagem Final", message: "Modele e coloque no banneton." },
  { time: "21:00", label: "2ª Fermentação", message: "Fermentar a 28°C por 2h ou levar à geladeira." },
  { time: "23:00", label: "Assar", message: "Pré-aqueça a panela e asse com/sem tampa." }
];

export default function App() {
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const currentTime = now.toTimeString().slice(0, 5);
      const step = steps.find((s) => s.time === currentTime);
      if (step) {
        alert(`Etapa: ${step.label}\n${step.message}`);
      }
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4 grid gap-4">
      {steps.map((step, idx) => (
        <div key={idx} className="shadow-md border p-4 rounded bg-white">
          <h2 className="text-lg font-semibold">{step.time} – {step.label}</h2>
          <p>{step.message}</p>
        </div>
      ))}
      <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded" onClick={() => alert("O app irá te alertar automaticamente a cada etapa, conforme o relógio do sistema.")}>
        Como funciona?
      </button>
    </div>
  );
}
